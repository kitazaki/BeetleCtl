# BeetleC-Control
<IMG WIDTH=200 SRC="https://user-images.githubusercontent.com/54971000/67201244-d0392100-f440-11e9-9dbd-0af2e0747e67.jpg"><IMG WIDTH=355 SRC="https://user-images.githubusercontent.com/54971000/67201172-a67ffa00-f440-11e9-93c0-99e49043aca7.JPG"><BR>

M5StickCのBeetleCをゲームパッドから操作するWindows用のアプリです。<BR>
<IMG SRC="https://user-images.githubusercontent.com/54971000/67200955-15108800-f440-11e9-8f3d-fb2a0cbe0e4d.jpg"><BR>

# 使い方

1. 本サイトからZip形式でダウンロードしてください。<BR>
　 お好きなフォルダにZipを展開してください。<BR>
  
2. PCに適当なゲームパッドを接続してください。<BR>
　　(Windowsが認識すれば何でもいいです）<BR>

3. PCをBeetleCにWifiで接続してください。<BR>
　　※BeetleCは、M5Stickに公式サイトの初期のアプリだけ入れておいてください。<BR>

4. アプリ(BeetleCtl.exe)を起動して、「開始」ボタンを押してください。<BR>

5. これでゲームパッドで操作できる様になります。<BR>
【操作】<BR>
   十字キー上：　前進<BR>
   十字キー下：　後退<BR>
   十字キー左：　左旋回<BR>
   十字キー右：　右旋回<BR>
   ボタン１：　　スピードアップ<BR>
   ボタン２：　　スピードダウン<BR>
　　※スピードに応じて車体のLEDの色が変わります。<BR>
  
■ Qiitaの記事へリンク<BR>
  https://qiita.com/yi_2018/items/822811c0ba29725354ee
